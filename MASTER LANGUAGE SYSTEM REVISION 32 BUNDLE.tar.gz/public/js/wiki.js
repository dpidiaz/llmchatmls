(()=>{
  'use strict';
  const MLS=window.MLS;
  async function hydrateEntry(entry,meta){
    const shell=document.getElementById('wikiArticleSection');
    const button=document.getElementById('wikiArticleBtn');
    if(!shell||!button)return;
    try{
      const response=await fetch(`/api/wiki/article/${encodeURIComponent(entry.code)}`,{headers:{accept:'application/json'},cache:'no-store'});
      if(response.status===404)return;
      if(!response.ok)return;
      const data=await response.json(),article=data?.article;
      if(!article?.articleMarkdown)return;
      const body=shell.querySelector('[data-wiki-body]');
      const metaLine=shell.querySelector('[data-wiki-meta]');
      if(body)body.innerHTML=MLS.renderMarkdown(article.articleMarkdown,entry.language);
      if(metaLine){
        const date=article.generatedAt?new Date(article.generatedAt).toLocaleDateString('es-GT',{year:'numeric',month:'short',day:'numeric'}):'';
        metaLine.textContent=`Artículo desarrollado automáticamente${date?` · ${date}`:''}`;
      }
      shell.hidden=false;button.hidden=false;
      button.onclick=()=>shell.scrollIntoView({behavior:'smooth',block:'start'});
    }catch(_){/* La enciclopedia original funciona aunque la wiki no esté disponible. */}
  }
  async function status(){
    const r=await fetch('/api/wiki/status',{cache:'no-store'});
    if(!r.ok)throw new Error(`HTTP ${r.status}`);
    return r.json();
  }
  MLS.wiki={hydrateEntry,status};
})();
