(()=>{
  'use strict';
  const MLS=window.MLS;
  const {esc,escAttr,clamp,fmt,short}=MLS.util;

  const levelClass=l=>`level-${String(l||'').toLowerCase().replace(/[^a-z0-9]+/g,'-')}`;

  function globalMapPage(){
    const W=1000,regionW=440,regionH=230,gapX=40,gapY=30,startX=35,startY=38;
    let svg=[`<svg id="globalKnowledgeMap" class="knowledge-svg global-knowledge-svg" viewBox="0 0 ${W} 1360" role="img" aria-label="Atlas global de las diez enciclopedias">`];
    MLS_META.forEach((m,i)=>{
      const col=i%2,row=Math.floor(i/2),x=startX+col*(regionW+gapX),y=startY+row*(regionH+gapY);
      const arr=MLS.data.byLanguage[m.slug]||[];const byChapter=new Map();
      for(const e of arr){const k=String(e.chapterNum);if(!byChapter.has(k))byChapter.set(k,[]);byChapter.get(k).push(e)}
      svg.push(`<g class="language-region" data-language-region="${m.slug}" tabindex="0" role="button" aria-label="Abrir atlas de ${escAttr(m.name)}">
        <rect class="language-region-bg" x="${x}" y="${y}" width="${regionW}" height="${regionH}" rx="22"/>
        <text class="language-region-flag" x="${x+24}" y="${y+43}">${m.flag}</text>
        <text class="language-region-title" x="${x+70}" y="${y+39}">${esc(m.name)}</text>
        <text class="language-region-native" x="${x+70}" y="${y+60}">${esc(m.native)}</text>
        <text class="language-region-count" x="${x+24}" y="${y+88}">${fmt(m.count)} entradas · 25 partes · 58 capítulos</text>`);
      const cols=15,node=13,gap=6,nx=x+24,ny=y+111;
      [...byChapter.entries()].sort((a,b)=>Number(a[0])-Number(b[0])).forEach(([ch,ents],j)=>{
        const cx=nx+(j%cols)*(node+gap),cy=ny+Math.floor(j/cols)*(node+gap);
        svg.push(`<rect class="chapter-mini" x="${cx}" y="${cy}" width="${node}" height="${node}" rx="3" data-mini-chapter="${ch}" data-language="${m.slug}" data-count="${ents.length}"/>`);
      });
      svg.push(`<text class="language-region-hint" x="${x+24}" y="${y+205}">Abrir atlas del idioma →</text></g>`);
    });
    svg.push('</svg>');
    MLS.app.innerHTML=`<section class="map-page-head"><div><div class="eyebrow">Atlas conceptual · navegación espacial</div><h1>Mapa global de la biblioteca</h1><p>Diez enciclopedias. Cada pequeño cuadro representa un capítulo. El atlas no impone una ruta: cualquier región, capítulo o entrada permanece libremente accesible.</p></div><div class="map-head-count"><strong>10,133</strong><span>entradas consultables</span></div></section>
      <div class="map-toolbar"><button class="btn" id="globalFit">Ajustar</button><button class="btn" id="globalZoomIn">＋</button><button class="btn" id="globalZoomOut">−</button><button class="btn" onclick="location.hash='#search'">⌕ Buscar</button><span class="map-help">Arrastra · rueda/pellizca para zoom</span></div>
      <div class="knowledge-map-shell" id="globalMapShell">${svg.join('')}<div id="globalTooltip" class="map-tooltip" hidden></div></div>
      <div class="legend panel"><strong>Cómo leer el atlas</strong><span>Idioma → nivel → capítulo → entrada.</span><small>Los cuadros no representan progreso ni desbloqueo.</small></div>`;
    const el=document.getElementById('globalKnowledgeMap');const pz=initPanZoom(el,{x:0,y:0,w:1000,h:1360});
    document.getElementById('globalFit').onclick=pz.fit;document.getElementById('globalZoomIn').onclick=()=>pz.zoomCenter(.8);document.getElementById('globalZoomOut').onclick=()=>pz.zoomCenter(1.25);
    el.addEventListener('click',ev=>{const g=ev.target.closest?.('[data-language-region]');if(g)location.hash=`#map=${g.dataset.languageRegion}`});
    el.addEventListener('keydown',ev=>{if(ev.key==='Enter'||ev.key===' '){const g=ev.target.closest?.('[data-language-region]');if(g){ev.preventDefault();location.hash=`#map=${g.dataset.languageRegion}`}}});
    const tt=document.getElementById('globalTooltip');
    el.addEventListener('pointermove',ev=>{const r=ev.target.closest?.('.chapter-mini');if(!r){tt.hidden=true;return}const m=MLS.data.metaBySlug[r.dataset.language];const sample=MLS.data.byLanguage[r.dataset.language].find(e=>String(e.chapterNum)===r.dataset.miniChapter);tt.innerHTML=`<strong>${m.flag} ${esc(m.name)} · Cap. ${esc(r.dataset.miniChapter)}</strong><span>${esc(short(sample?.chapter||''))}</span><small>${esc(r.dataset.count)} entradas</small>`;tt.hidden=false;positionTooltip(tt,ev)});
    el.addEventListener('pointerleave',()=>tt.hidden=true);
  }

  function parseParams(){
    const h=location.hash;const amp=h.indexOf('&');if(amp<0)return new URLSearchParams();return new URLSearchParams(h.slice(amp+1));
  }

  function buildLayout(slug,levelFilter=''){
    const source=(MLS.data.byLanguage[slug]||[]).filter(e=>!levelFilter||e.level===levelFilter);
    const levels=[...new Set(source.map(e=>e.level))].sort((a,b)=>(MLS.data.levelOrder[a]??99)-(MLS.data.levelOrder[b]??99));
    const node=16,gap=6,pad=22,maxW=2450;let y=48,maxX=0;const positions={},blocks=[],levelBands=[];
    for(const level of levels){
      const bandStart=y;let x=40,rowH=0;const byCh=new Map();
      for(const e of source.filter(q=>q.level===level)){const k=String(e.chapterNum);if(!byCh.has(k))byCh.set(k,{chapterNum:k,title:e.chapter,entries:[]});byCh.get(k).entries.push(e)}
      const chapters=[...byCh.values()].sort((a,b)=>Number(a.chapterNum)-Number(b.chapterNum));y+=52;
      for(const ch of chapters){
        const count=ch.entries.length,cols=Math.min(13,Math.max(5,Math.ceil(Math.sqrt(count*1.75)))),rows=Math.ceil(count/cols);
        const w=pad*2+cols*node+(cols-1)*gap,h=78+rows*node+(rows-1)*gap+pad;
        if(x+w>maxW&&x>45){x=40;y+=rowH+24;rowH=0}
        const block={...ch,x,y,w,h,level};blocks.push(block);maxX=Math.max(maxX,x+w);
        ch.entries.sort((a,b)=>a.n-b.n).forEach((e,j)=>{const col=j%cols,row=Math.floor(j/cols);positions[e.code]={x:x+pad+col*(node+gap),y:y+58+row*(node+gap),size:node,entry:e,block}});
        x+=w+20;rowH=Math.max(rowH,h);
      }
      y+=rowH+60;levelBands.push({level,y:bandStart,h:y-bandStart-18});
    }
    return {source,levels,positions,blocks,levelBands,bounds:{x:0,y:0,w:Math.max(maxX+55,800),h:y+30},node};
  }

  async function languageMapPage(slug){
    const m=MLS.data.metaBySlug[slug];if(!m){globalMapPage();return}
    MLS.state.mapPrefs.lastLanguage=slug;MLS.save();
    const params=parseParams(),levelFilter=params.get('level')||'',focusCode=params.get('entry')||'';
    const layout=buildLayout(slug,levelFilter);const allLevels=MLS.structureFor(slug).levels;let related=[];
    if(focusCode){
      const vol=await MLS.loadVolume(slug);const focus=vol.entries.find(e=>e.code===focusCode);if(focus)related=MLS.extractRelations(focus.body,slug);
    }
    const relatedSet=new Set(related.map(x=>x.code));const connections=MLS.state.mapPrefs.connections!==false;
    let svg=[`<svg id="languageKnowledgeMap" class="knowledge-svg language-knowledge-svg zoom-mid" viewBox="0 0 ${layout.bounds.w} ${layout.bounds.h}" role="img" aria-label="Atlas conceptual de ${escAttr(m.name)}"><g class="map-content">`];
    for(const band of layout.levelBands)svg.push(`<rect class="level-band ${levelClass(band.level)}" x="12" y="${band.y}" width="${layout.bounds.w-24}" height="${band.h}" rx="28"/><text class="level-title" x="38" y="${band.y+34}">${esc(band.level)}</text>`);
    if(connections&&focusCode&&layout.positions[focusCode]){
      const a=layout.positions[focusCode];for(const r of related){const b=layout.positions[r.code];if(!b)continue;const ax=a.x+a.size/2,ay=a.y+a.size/2,bx=b.x+b.size/2,by=b.y+b.size/2,mx=(ax+bx)/2;svg.push(`<path class="connection-line explicit-connection" d="M ${ax} ${ay} C ${mx} ${ay}, ${mx} ${by}, ${bx} ${by}"/>`)}
    }
    for(const block of layout.blocks){
      svg.push(`<g class="chapter-group" data-chapter="${block.chapterNum}" data-level="${escAttr(block.level)}"><rect class="chapter-block" x="${block.x}" y="${block.y}" width="${block.w}" height="${block.h}" rx="16"/><text class="chapter-label chapter-link" x="${block.x+18}" y="${block.y+25}" data-chapter-link="${block.chapterNum}" data-level-link="${escAttr(block.level)}">Parte ${esc(block.entries[0]?.partNum||'—')} · Cap. ${block.chapterNum}</text><text class="chapter-title chapter-link" x="${block.x+18}" y="${block.y+44}" data-chapter-link="${block.chapterNum}" data-level-link="${escAttr(block.level)}">${esc(shorten(block.title,38))}</text><text class="chapter-count" x="${block.x+block.w-16}" y="${block.y+25}" text-anchor="end">${block.entries.length}</text></g>`);
    }
    for(const e of layout.source){
      const p=layout.positions[e.code];const cls=[levelClass(e.level),e.code===focusCode?'node-focus':'',relatedSet.has(e.code)?'node-related':''].filter(Boolean).join(' ');
      svg.push(`<rect class="entry-node ${cls}" x="${p.x}" y="${p.y}" width="${p.size}" height="${p.size}" rx="3" tabindex="0" role="button" aria-label="${escAttr(`${e.code}. ${e.title}`)}" data-code="${e.code}" data-language="${slug}" data-level="${escAttr(e.level)}" data-part="${escAttr(e.partNum)}" data-chapter="${escAttr(e.chapterNum)}" data-entry="${e.n}"/>`);
    }
    svg.push('</g></svg>');
    const mini=`<svg id="miniMap" class="mini-map" viewBox="0 0 ${layout.bounds.w} ${layout.bounds.h}" aria-label="Minimapa">${layout.blocks.map(b=>`<rect x="${b.x}" y="${b.y}" width="${b.w}" height="${b.h}" rx="10"/>`).join('')}<rect id="miniViewport" class="mini-viewport" x="0" y="0" width="${layout.bounds.w}" height="${layout.bounds.h}"/></svg>`;
    MLS.app.innerHTML=`<div class="crumbs"><a href="#home">Biblioteca</a><span>›</span><a href="#map">Atlas global</a><span>›</span><a href="#lang=${slug}">${m.flag} ${esc(m.name)}</a>${levelFilter?`<span>›</span><span>${esc(levelFilter)}</span>`:''}</div>
      <section class="map-page-head"><div><div class="eyebrow">Volumen ${String(m.v).padStart(2,'0')} · atlas SVG</div><h1>${m.flag} ${esc(m.name)}</h1><p>${fmt(m.count)} entradas organizadas espacialmente por nivel y capítulo. El mapa es un índice visual: ningún nodo está bloqueado y no existe una secuencia obligatoria.</p></div><div class="map-head-count"><strong>${fmt(layout.source.length)}</strong><span>${levelFilter?'entradas visibles':'entradas del volumen'}</span></div></section>
      <div class="map-toolbar sticky-map-toolbar">
        <button class="btn" onclick="location.hash='#map'">← Global</button>
        <select id="mapLevel" aria-label="Filtrar por nivel"><option value="">Todos los niveles</option>${allLevels.map(l=>`<option value="${escAttr(l)}" ${l===levelFilter?'selected':''}>${esc(l)}</option>`).join('')}</select>
        <button class="btn" id="fitMap">Ajustar</button><button class="btn" id="zoomIn">＋</button><button class="btn" id="zoomOut">−</button>
        ${focusCode?`<button class="btn ${connections?'active-toggle':''}" id="connectionToggle">Relaciones explícitas: ${connections?'SÍ':'NO'}</button><button class="btn" id="clearFocus">Limpiar foco</button>`:''}
        <span class="map-help">Arrastra · rueda/pellizca · clic = abrir entrada</span>
      </div>
      ${focusCode?`<div class="focus-strip panel"><strong>Foco:</strong> ${esc(focusCode)}${related.length?` · ${related.length} referencias explícitas «Véase también»`: ' · sin referencias internas explícitas detectadas'}</div>`:''}
      <div class="knowledge-map-shell" id="languageMapShell">${svg.join('')}${mini}<div id="mapTooltip" class="map-tooltip" hidden></div></div>
      <div class="legend panel"><strong>Atlas libre</strong><span>Los fondos separan niveles y los bloques delimitan capítulos.</span>${focusCode?`<small>Las líneas visibles proceden de referencias internas explícitas del master, no de prerrequisitos.</small>`:''}</div>`;
    const mapSvg=document.getElementById('languageKnowledgeMap'),pz=initPanZoom(mapSvg,layout.bounds,true,document.getElementById('miniMap'));
    document.getElementById('fitMap').onclick=pz.fit;document.getElementById('zoomIn').onclick=()=>pz.zoomCenter(.8);document.getElementById('zoomOut').onclick=()=>pz.zoomCenter(1.25);
    document.getElementById('mapLevel').onchange=ev=>{const l=ev.target.value;location.hash=`#map=${slug}${l?`&level=${encodeURIComponent(l)}`:''}${focusCode?`&entry=${encodeURIComponent(focusCode)}`:''}`};
    if(focusCode){document.getElementById('connectionToggle').onclick=()=>{MLS.state.mapPrefs.connections=!connections;MLS.save();languageMapPage(slug)};document.getElementById('clearFocus').onclick=()=>{location.hash=`#map=${slug}${levelFilter?`&level=${encodeURIComponent(levelFilter)}`:''}`}}
    mapSvg.addEventListener('click',ev=>{
      const n=ev.target.closest?.('.entry-node');if(n){location.hash=`#entry=${n.dataset.code}`;return}
      const c=ev.target.closest?.('[data-chapter-link]');if(c)location.hash=`#lang=${slug}&chapter=${encodeURIComponent(c.dataset.chapterLink)}`;
    });
    mapSvg.addEventListener('keydown',ev=>{if(ev.key==='Enter'||ev.key===' '){const n=ev.target.closest?.('.entry-node');if(n){ev.preventDefault();location.hash=`#entry=${n.dataset.code}`}}});
    const tt=document.getElementById('mapTooltip');
    mapSvg.addEventListener('pointermove',ev=>{const n=ev.target.closest?.('.entry-node');if(!n){tt.hidden=true;return}const e=MLS.data.idxByCode[n.dataset.code];tt.innerHTML=`<strong>${esc(e.code)} · ${esc(e.title)}</strong>${e.target?`<span>${esc(e.target)}</span>`:''}<span>${esc(e.level)} · Parte ${esc(e.partNum)} · Cap. ${esc(e.chapterNum)}</span>${relatedSet.has(e.code)?'<small>Relacionado explícitamente con la entrada enfocada.</small>':''}`;tt.hidden=false;positionTooltip(tt,ev)});
    mapSvg.addEventListener('pointerleave',()=>tt.hidden=true);
    if(focusCode&&layout.positions[focusCode])requestAnimationFrame(()=>pz.centerOn(layout.positions[focusCode].x,layout.positions[focusCode].y,Math.max(layout.bounds.w/4,520)));
  }

  function positionTooltip(tt,ev){const pad=14;tt.style.left=`${Math.min(ev.clientX+16,window.innerWidth-tt.offsetWidth-pad)}px`;tt.style.top=`${Math.min(ev.clientY+16,window.innerHeight-tt.offsetHeight-pad)}px`}
  function shorten(s,n){const t=short(s);return t.length>n?t.slice(0,n-1)+'…':t}

  function initPanZoom(svg,bounds,semantic=false,mini=null){
    let vb={x:bounds.x,y:bounds.y,w:bounds.w,h:bounds.h},dragging=false,last=null;const pointers=new Map();let pinch=null;
    const set=()=>{svg.setAttribute('viewBox',`${vb.x} ${vb.y} ${vb.w} ${vb.h}`);if(semantic)applySemantic(svg,bounds.w/vb.w);if(mini){const vr=mini.querySelector('.mini-viewport');if(vr){vr.setAttribute('x',vb.x);vr.setAttribute('y',vb.y);vr.setAttribute('width',vb.w);vr.setAttribute('height',vb.h)}}};
    const fit=()=>{const rect=svg.getBoundingClientRect(),ar=rect.width/Math.max(1,rect.height);let w=bounds.w*1.04,h=bounds.h*1.04;if(w/h>ar)h=w/ar;else w=h*ar;vb={x:bounds.x+(bounds.w-w)/2,y:bounds.y+(bounds.h-h)/2,w,h};set()};
    const zoomAt=(factor,cx,cy)=>{const r=svg.getBoundingClientRect(),px=(cx-r.left)/Math.max(1,r.width),py=(cy-r.top)/Math.max(1,r.height),wx=vb.x+px*vb.w,wy=vb.y+py*vb.h,nw=clamp(vb.w*factor,bounds.w/9,bounds.w*4),nh=nw*(r.height/Math.max(1,r.width));vb.x=wx-px*nw;vb.y=wy-py*nh;vb.w=nw;vb.h=nh;set()};
    const zoomCenter=f=>{const r=svg.getBoundingClientRect();zoomAt(f,r.left+r.width/2,r.top+r.height/2)};
    const centerOn=(x,y,w=Math.max(bounds.w/3,600))=>{const r=svg.getBoundingClientRect();vb.w=clamp(w,bounds.w/9,bounds.w*4);vb.h=vb.w*(r.height/Math.max(1,r.width));vb.x=x-vb.w/2;vb.y=y-vb.h/2;set()};
    svg.addEventListener('wheel',ev=>{ev.preventDefault();zoomAt(ev.deltaY>0?1.12:.88,ev.clientX,ev.clientY)},{passive:false});
    svg.addEventListener('pointerdown',ev=>{if(ev.target.closest?.('.entry-node,.language-region,.chapter-link'))return;svg.setPointerCapture?.(ev.pointerId);pointers.set(ev.pointerId,{x:ev.clientX,y:ev.clientY});if(pointers.size===1){dragging=true;last={x:ev.clientX,y:ev.clientY}}else if(pointers.size===2){const a=[...pointers.values()];pinch={dist:Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y),w:vb.w}}});
    svg.addEventListener('pointermove',ev=>{if(!pointers.has(ev.pointerId))return;pointers.set(ev.pointerId,{x:ev.clientX,y:ev.clientY});if(pointers.size===2&&pinch){const a=[...pointers.values()],d=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);if(d>5){const factor=pinch.dist/d,c={x:(a[0].x+a[1].x)/2,y:(a[0].y+a[1].y)/2};zoomAt((pinch.w*factor)/vb.w,c.x,c.y)}return}if(dragging&&last){const r=svg.getBoundingClientRect(),dx=(ev.clientX-last.x)*vb.w/Math.max(1,r.width),dy=(ev.clientY-last.y)*vb.h/Math.max(1,r.height);vb.x-=dx;vb.y-=dy;last={x:ev.clientX,y:ev.clientY};set()}});
    const end=ev=>{pointers.delete(ev.pointerId);if(pointers.size<2)pinch=null;if(!pointers.size){dragging=false;last=null}};svg.addEventListener('pointerup',end);svg.addEventListener('pointercancel',end);svg.addEventListener('pointerleave',ev=>{if(ev.buttons===0)end(ev)});
    if(mini)mini.addEventListener('click',ev=>{const r=mini.getBoundingClientRect(),wx=bounds.x+((ev.clientX-r.left)/Math.max(1,r.width))*bounds.w,wy=bounds.y+((ev.clientY-r.top)/Math.max(1,r.height))*bounds.h;vb.x=wx-vb.w/2;vb.y=wy-vb.h/2;set()});
    requestAnimationFrame(fit);return{fit,zoomCenter,centerOn};
  }
  function applySemantic(svg,z){svg.classList.remove('zoom-far','zoom-mid','zoom-near');svg.classList.add(z<.6?'zoom-far':z<2?'zoom-mid':'zoom-near')}

  MLS.map={globalMapPage,languageMapPage,buildLayout};
  MLS.pages.map=()=>{const h=location.hash;if(h.startsWith('#map='))return languageMapPage(h.slice(5).split('&')[0]);return globalMapPage()};
})();
