(()=>{
  'use strict';
  const MLS=window.MLS;
  const sessions=new Map();
  const MAX_HISTORY=16;

  function online(){return navigator.onLine!==false}
  function sessionFor(code){
    if(!sessions.has(code))sessions.set(code,[]);
    return sessions.get(code);
  }
  function text(el,value){el.textContent=value==null?'':String(value)}
  function make(tag,cls){const el=document.createElement(tag);if(cls)el.className=cls;return el}
  function addMessage(container,role,content){
    const row=make('div',`ai-message ${role}`),bubble=make('div','ai-bubble');
    const label=make('div','ai-role');text(label,role==='user'?'Tú':'Profesor IA');
    const body=make('div','ai-text');text(body,content);
    bubble.append(label,body);row.append(bubble);container.append(row);
    container.scrollTop=container.scrollHeight;
    return {row,body};
  }
  function contextFromEntry(entry,meta){
    const plain=entry.plain||{};
    const details=[];
    if(entry.target)details.push(`Forma o tema objetivo:\n${entry.target}`);
    if(plain.look)details.push(`Nota visible:\n${plain.look}`);
    const advanced=String(entry.auditedBody||entry.body||'').slice(0,12000);
    if(advanced)details.push(`Detalles de referencia:\n${advanced}`);
    return {
      code:entry.code,
      language:meta?.name||entry.language||'',
      level:entry.level||'',
      part:String(entry.part||entry.partNum||''),
      chapter:String(entry.chapter||entry.chapterNum||''),
      title:entry.title||'',
      definition:plain.lead||entry.definition||'',
      examples:[plain.example||''].filter(Boolean),
      content:details.join('\n\n')
    };
  }
  function status(modal,msg,kind=''){
    const el=modal.querySelector('[data-ai-status]');
    if(!el)return;
    el.className=`ai-status ${kind}`;text(el,msg||'');
  }
  function setBusy(modal,busy){
    const send=modal.querySelector('[data-ai-send]'),input=modal.querySelector('[data-ai-input]');
    if(send)send.disabled=busy;
    if(input)input.disabled=busy;
    modal.dataset.aiBusy=busy?'1':'0';
  }
  function pieceFromEvent(data){
    if(!data||data==='[DONE]')return '';
    try{
      const obj=JSON.parse(data);
      const candidates=[
        obj?.response,
        obj?.delta?.content,
        obj?.result?.response,
        obj?.choices?.[0]?.delta?.content,
        obj?.choices?.[0]?.message?.content,
        obj?.message?.content,
        obj?.text
      ];
      for(const value of candidates){
        if(typeof value==='string'&&value)return value;
      }
      return '';
    }catch(_){
      return data;
    }
  }
  function appendSSEChunk(buffer,onPiece){
    let rest=buffer;
    const events=rest.split(/\r?\n\r?\n/);
    rest=events.pop()||'';
    for(const event of events){
      for(const line of event.split(/\r?\n/)){
        if(!line.startsWith('data:'))continue;
        const piece=pieceFromEvent(line.slice(5).trim());
        if(piece)onPiece(piece);
      }
    }
    return rest;
  }
  async function streamAnswer(response,onPiece){
    if(!response.body||typeof response.body.getReader!=='function'){
      const raw=await response.text();
      appendSSEChunk(`${raw}\n\n`,onPiece);
      return;
    }
    const reader=response.body.getReader(),decoder=new TextDecoder();
    let buffer='';
    while(true){
      const {value,done}=await reader.read();
      if(done)break;
      buffer+=decoder.decode(value,{stream:true});
      buffer=appendSSEChunk(buffer,onPiece);
    }
    buffer+=decoder.decode();
    appendSSEChunk(`${buffer}\n\n`,onPiece);
  }
  async function errorMessage(response){
    const raw=await response.text().catch(()=> '');
    try{
      const data=JSON.parse(raw);
      return String(data?.error||data?.message||`Error ${response.status}`);
    }catch(_){
      return raw.trim()||`Error ${response.status}`;
    }
  }
  async function ask(entry,meta,question,modal,{automatic=false}={}){
    if(modal.dataset.aiBusy==='1')return;
    if(!online()){status(modal,'Necesitas conexión a Internet para consultar al Profesor IA.','error');return}
    const history=sessionFor(entry.code),messages=modal.querySelector('[data-ai-messages]'),input=modal.querySelector('[data-ai-input]');
    const q=String(question||'').trim();
    let userWasAdded=false;
    if(!automatic&&q){
      addMessage(messages,'user',q);
      history.push({role:'user',content:q});
      userWasAdded=true;
    }
    if(input)input.value='';
    setBusy(modal,true);
    status(modal,automatic?'Preparando una explicación de esta entrada…':'Pensando en tu pregunta…','loading');
    const assistant=addMessage(messages,'assistant','');
    assistant.row.classList.add('ai-streaming');
    let answer='';
    try{
      const response=await fetch('/api/chat',{
        method:'POST',
        headers:{'content-type':'application/json','accept':'text/event-stream'},
        body:JSON.stringify({
          entry:contextFromEntry(entry,meta),
          messages:history.slice(-MAX_HISTORY)
        })
      });
      if(!response.ok)throw new Error(await errorMessage(response));
      await streamAnswer(response,piece=>{
        answer+=piece;
        text(assistant.body,answer);
        messages.scrollTop=messages.scrollHeight;
      });
      answer=answer.trim();
      if(!answer)throw new Error('La IA no devolvió una explicación.');
      text(assistant.body,answer);
      history.push({role:'assistant',content:answer});
      if(history.length>MAX_HISTORY*2)history.splice(0,history.length-MAX_HISTORY*2);
      status(modal,'');
    }catch(err){
      assistant.row.remove();
      if(userWasAdded&&history[history.length-1]?.role==='user'&&history[history.length-1]?.content===q)history.pop();
      const raw=String(err?.message||err||'');
      const friendly=/404|Failed to fetch|NetworkError/i.test(raw)
        ?'El Profesor IA todavía no está conectado en este despliegue.'
        :`No pude obtener la explicación: ${raw}`;
      status(modal,friendly,'error');
    }finally{
      assistant.row.classList.remove('ai-streaming');
      setBusy(modal,false);
      input?.focus();
    }
  }
  function open(entry,meta){
    document.getElementById('aiTutorModal')?.remove();
    const modal=make('div','ai-modal');modal.id='aiTutorModal';modal.setAttribute('role','dialog');modal.setAttribute('aria-modal','true');modal.setAttribute('aria-label','Profesor IA');
    modal.innerHTML=`<div class="ai-sheet">
      <header class="ai-head"><div><small>Consulta opcional · requiere Internet</small><h2>Profesor IA</h2><p></p></div><button type="button" class="iconbtn" data-ai-close aria-label="Cerrar">×</button></header>
      <div class="ai-context"><span>Estás consultando</span><strong></strong></div>
      <div class="ai-quick" aria-label="Preguntas rápidas">
        <button type="button" data-q="Explícamelo todavía más fácil, sin perder precisión.">Más simple</button>
        <button type="button" data-q="Dame más ejemplos y explícame por qué cada uno funciona.">Más ejemplos</button>
        <button type="button" data-q="Explícamelo paso a paso y define cualquier término técnico que uses.">Paso a paso</button>
        <button type="button" data-q="Compáralo con el español de Guatemala cuando sea útil.">Comparar con español</button>
      </div>
      <div class="ai-messages" data-ai-messages aria-live="polite"></div>
      <div class="ai-status" data-ai-status aria-live="polite"></div>
      <form class="ai-compose" data-ai-form><textarea data-ai-input rows="2" maxlength="1200" placeholder="Pregunta algo sobre este tema…"></textarea><button class="btn primary" data-ai-send type="submit">Preguntar</button></form>
      <footer>Profesor IA puede equivocarse. La entrada original de la enciclopedia permanece disponible sin conexión.</footer>
    </div>`;
    text(modal.querySelector('.ai-head p'),`Puedo ampliar esta entrada de ${meta?.name||'la enciclopedia'} y responder preguntas sobre el mismo tema.`);
    text(modal.querySelector('.ai-context strong'),entry.title);
    const messages=modal.querySelector('[data-ai-messages]'),history=sessionFor(entry.code);
    if(history.length)history.forEach(m=>addMessage(messages,m.role==='assistant'?'assistant':'user',m.content));
    const close=()=>{modal.remove();document.body.classList.remove('ai-open')};
    modal.querySelector('[data-ai-close]').onclick=close;
    modal.addEventListener('click',ev=>{if(ev.target===modal)close()});
    modal.querySelectorAll('[data-q]').forEach(b=>b.onclick=()=>ask(entry,meta,b.dataset.q,modal));
    modal.querySelector('[data-ai-form]').onsubmit=ev=>{ev.preventDefault();const input=modal.querySelector('[data-ai-input]'),q=input.value.trim();if(q)ask(entry,meta,q,modal)};
    document.body.append(modal);document.body.classList.add('ai-open');
    if(!history.length)setTimeout(()=>ask(entry,meta,'',modal,{automatic:true}),80);
    else setTimeout(()=>modal.querySelector('[data-ai-input]')?.focus(),50);
  }
  MLS.aiTutor={open};
})();
