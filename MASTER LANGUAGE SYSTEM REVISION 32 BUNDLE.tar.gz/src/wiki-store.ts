import { DurableObject } from "cloudflare:workers";
import type { Env } from "./types";
import {
	WIKI_CLAIM_TTL_MS,
	WIKI_CLOUDFLARE_NEURON_TARGET,
	WIKI_LANGUAGE_ORDER,
	WIKI_PROMPT_VERSION,
	WIKI_TOTAL_ENTRIES,
} from "./wiki-config";

interface ActiveClaim {
	code: string;
	language: string;
	languageName: string;
	n: number;
	seedPath: string;
	claimedAt: number;
}

interface LastPublished {
	code: string;
	language: string;
	title: string;
	generatedAt: string;
}

interface WikiState {
	version: number;
	startedAt: string;
	languageIndex: number;
	nextN: number;
	totalPublished: number;
	totalFailed: number;
	completedByLanguage: Record<string, number>;
	failedByLanguage: Record<string, number>;
	dailyDate: string;
	dailyClaims: number;
	dailyPromptTokens: number;
	dailyCompletionTokens: number;
	dailyNeurons: number;
	dailyReservedNeurons: number;
	historicalArticleNeurons: number;
	historicalArticleCount: number;
	quotaExhaustedDate: string | null;
	claim: ActiveClaim | null;
	lastPublished: LastPublished | null;
	lastError: { code: string; message: string; at: string } | null;
}

interface PublishedArticle {
	code: string;
	language: string;
	languageName: string;
	n: number;
	title: string;
	level: string;
	part: string;
	chapter: string;
	articleMarkdown: string;
	model: string;
	promptVersion: string;
	generatedAt: string;
}

function utcDate(now = Date.now()): string {
	return new Date(now).toISOString().slice(0, 10);
}

function initialCounts(): Record<string, number> {
	return Object.fromEntries(WIKI_LANGUAGE_ORDER.map((language) => [language.slug, 0]));
}

function defaultState(): WikiState {
	return {
		version: 1,
		startedAt: new Date().toISOString(),
		languageIndex: 0,
		nextN: 1,
		totalPublished: 0,
		totalFailed: 0,
		completedByLanguage: initialCounts(),
		failedByLanguage: initialCounts(),
		dailyDate: utcDate(),
		dailyClaims: 0,
		dailyPromptTokens: 0,
		dailyCompletionTokens: 0,
		dailyNeurons: 0,
		dailyReservedNeurons: 0,
		historicalArticleNeurons: 0,
		historicalArticleCount: 0,
		quotaExhaustedDate: null,
		claim: null,
		lastPublished: null,
		lastError: null,
	};
}

export class WikiStore extends DurableObject<Env> {
	constructor(ctx: DurableObjectState, env: Env) {
		super(ctx, env);
	}

	private async state(): Promise<WikiState> {
		const stored = await this.ctx.storage.get<WikiState>("wiki:state");
		if (stored) {
			stored.dailyPromptTokens ??= 0;
			stored.dailyCompletionTokens ??= 0;
			stored.dailyNeurons ??= 0;
			stored.dailyReservedNeurons ??= 0;
			stored.historicalArticleNeurons ??= 0;
			stored.historicalArticleCount ??= 0;
			stored.quotaExhaustedDate ??= null;
			return stored;
		}
		const created = defaultState();
		await this.ctx.storage.put("wiki:state", created);
		return created;
	}

	private async saveState(state: WikiState): Promise<void> {
		await this.ctx.storage.put("wiki:state", state);
	}

	private normalizeDay(state: WikiState): void {
		const today = utcDate();
		if (state.dailyDate !== today) {
			state.dailyDate = today;
			state.dailyClaims = 0;
			state.dailyPromptTokens = 0;
			state.dailyCompletionTokens = 0;
			state.dailyNeurons = 0;
			state.dailyReservedNeurons = 0;
			state.quotaExhaustedDate = null;
		}
	}

	private normalizeCursor(state: WikiState): void {
		while (state.languageIndex < WIKI_LANGUAGE_ORDER.length) {
			const language = WIKI_LANGUAGE_ORDER[state.languageIndex];
			if (state.nextN <= language.total) return;
			state.languageIndex += 1;
			state.nextN = 1;
		}
	}

	async claimNext(): Promise<Record<string, unknown>> {
		const state = await this.state();
		const now = Date.now();
		this.normalizeDay(state);
		this.normalizeCursor(state);

		if (state.claim) {
			const age = now - state.claim.claimedAt;
			if (age < WIKI_CLAIM_TTL_MS) {
				await this.saveState(state);
				return {
					status: "busy",
					message: `Ya se está procesando ${state.claim.code}.`,
					claim: state.claim,
				};
			}
			state.lastError = {
				code: state.claim.code,
				message: "La reclamación anterior expiró y será reintentada.",
				at: new Date().toISOString(),
			};
			state.claim = null;
		}

		if (state.languageIndex >= WIKI_LANGUAGE_ORDER.length) {
			await this.saveState(state);
			return {
				status: "complete",
				message: "Las diez enciclopedias ya fueron recorridas.",
			};
		}

		if (state.quotaExhaustedDate === state.dailyDate) {
			await this.saveState(state);
			return {
				status: "daily-limit",
				message: "Cloudflare indicó que la cuota gratuita diaria de Workers AI ya se agotó; la wiki continuará después del reinicio UTC.",
			};
		}

		const averageArticleNeurons =
			state.historicalArticleCount > 0
				? state.historicalArticleNeurons / state.historicalArticleCount
				: 150;
		const remainingNeuronBudget = Math.max(0, WIKI_CLOUDFLARE_NEURON_TARGET - state.dailyNeurons);
		const minimumToStart = Math.max(
			100,
			averageArticleNeurons * 0.65,
		);

		if (state.dailyNeurons >= WIKI_CLOUDFLARE_NEURON_TARGET || remainingNeuronBudget < minimumToStart) {
			await this.saveState(state);
			return {
				status: "daily-limit",
				message: `Se alcanzó el presupuesto autónomo cercano al 95 % para ${state.dailyDate} UTC.`,
				dailyNeurons: state.dailyNeurons,
				targetNeurons: WIKI_CLOUDFLARE_NEURON_TARGET,
				remainingNeuronBudget,
				estimatedNextArticleNeurons: Math.round(averageArticleNeurons * 100) / 100,
			};
		}

		if (state.dailyClaims >= 96) {
			await this.saveState(state);
			return {
				status: "daily-limit",
				message: `Se alcanzó el límite de seguridad de ${96} intentos diarios.`,
			};
		}

		const language = WIKI_LANGUAGE_ORDER[state.languageIndex];
		const n = state.nextN;
		const padded = String(n).padStart(4, "0");
		const code = `${language.prefix}-${padded}`;
		const claim: ActiveClaim = {
			code,
			language: language.slug,
			languageName: language.name,
			n,
			seedPath: `/data/wiki-seeds/${language.slug}/${padded}.json`,
			claimedAt: now,
		};

		state.claim = claim;
		state.dailyClaims += 1;
		await this.saveState(state);
		return { status: "claimed", ...claim };
	}


	async recordUsage(
		code: string,
		phase: "draft" | "audit",
		promptTokens: number,
		completionTokens: number,
	): Promise<Record<string, unknown>> {
		const state = await this.state();
		this.normalizeDay(state);

		const safePromptTokens = Math.max(0, Math.trunc(Number(promptTokens) || 0));
		const safeCompletionTokens = Math.max(0, Math.trunc(Number(completionTokens) || 0));
		const usageKey = `usage:${state.dailyDate}:${code}:${phase}`;
		const alreadyRecorded = await this.ctx.storage.get(usageKey);

		if (alreadyRecorded) {
			return { ok: true, duplicate: true, dailyNeurons: state.dailyNeurons };
		}

		// Gemma 4 26B A4B: 9,091 neurons/M input + 27,273 neurons/M output.
		const neurons =
			(safePromptTokens * 9091) / 1_000_000 +
			(safeCompletionTokens * 27273) / 1_000_000;

		await this.ctx.storage.put(usageKey, {
			code,
			phase,
			promptTokens: safePromptTokens,
			completionTokens: safeCompletionTokens,
			neurons,
			at: new Date().toISOString(),
		});

		const articleUsageKey = `usage-article:${code}`;
		const articleUsage =
			(await this.ctx.storage.get<{ promptTokens: number; completionTokens: number; neurons: number }>(articleUsageKey)) ??
			{ promptTokens: 0, completionTokens: 0, neurons: 0 };
		articleUsage.promptTokens += safePromptTokens;
		articleUsage.completionTokens += safeCompletionTokens;
		articleUsage.neurons += neurons;
		await this.ctx.storage.put(articleUsageKey, articleUsage);

		state.dailyPromptTokens += safePromptTokens;
		state.dailyCompletionTokens += safeCompletionTokens;
		state.dailyNeurons += neurons;
		await this.saveState(state);

		return {
			ok: true,
			duplicate: false,
			neurons,
			dailyNeurons: state.dailyNeurons,
			targetNeurons: WIKI_CLOUDFLARE_NEURON_TARGET,
		};
	}

	async publish(article: PublishedArticle): Promise<{ ok: true; code: string }> {
		const state = await this.state();
		const key = `article:${article.code}`;
		const existing = await this.ctx.storage.get<PublishedArticle>(key);

		if (!existing) {
			await this.ctx.storage.put(key, article);
			const articleUsage = await this.ctx.storage.get<{ neurons: number }>(`usage-article:${article.code}`);
			if (articleUsage && Number.isFinite(articleUsage.neurons) && articleUsage.neurons > 0) {
				state.historicalArticleNeurons += articleUsage.neurons;
				state.historicalArticleCount += 1;
			}
		}

		if (state.claim?.code === article.code) {
			const language = WIKI_LANGUAGE_ORDER[state.languageIndex];
			if (language && language.slug === article.language && state.nextN === article.n) {
				state.totalPublished += existing ? 0 : 1;
				state.completedByLanguage[article.language] =
					(state.completedByLanguage[article.language] || 0) + (existing ? 0 : 1);
				state.nextN += 1;
				this.normalizeCursor(state);
			}
			state.claim = null;
		}

		state.lastPublished = {
			code: article.code,
			language: article.language,
			title: article.title,
			generatedAt: article.generatedAt,
		};
		state.lastError = null;

		const recent =
			(await this.ctx.storage.get<LastPublished[]>("wiki:recent")) ?? [];
		const updatedRecent = [state.lastPublished, ...recent.filter((item) => item.code !== article.code)].slice(0, 30);
		await this.ctx.storage.put("wiki:recent", updatedRecent);
		await this.saveState(state);
		return { ok: true, code: article.code };
	}


	async markQuotaExhausted(
		code: string,
		message: string,
	): Promise<Record<string, unknown>> {
		const state = await this.state();
		this.normalizeDay(state);
		state.quotaExhaustedDate = state.dailyDate;
		state.lastError = {
			code,
			message: `Cuota diaria de Workers AI agotada: ${message}`,
			at: new Date().toISOString(),
		};
		if (state.claim?.code === code) state.claim = null;
		await this.saveState(state);
		return { ok: false, quotaExhausted: true, code, dateUTC: state.dailyDate };
	}

	async recordFailure(
		code: string,
		message: string,
	): Promise<Record<string, unknown>> {
		const state = await this.state();
		const countKey = `failure-count:${code}`;
		const count = ((await this.ctx.storage.get<number>(countKey)) ?? 0) + 1;
		await this.ctx.storage.put(countKey, count);

		state.lastError = { code, message, at: new Date().toISOString() };

		let skipped = false;
		if (state.claim?.code === code) {
			if (count >= 3) {
				const language = state.claim.language;
				state.totalFailed += 1;
				state.failedByLanguage[language] = (state.failedByLanguage[language] || 0) + 1;
				await this.ctx.storage.put(`failure:${code}`, {
					code,
					message,
					attempts: count,
					at: new Date().toISOString(),
				});
				state.nextN += 1;
				this.normalizeCursor(state);
				skipped = true;
			}
			state.claim = null;
		}

		await this.saveState(state);
		return { ok: false, code, attempts: count, skipped };
	}


	/**
	 * Atomically reserves part of the autonomous Workers AI budget.
	 * Durable Objects serialize these mutations, preventing parallel Queue
	 * consumers from all starting expensive Cloudflare generations at once.
	 */
	async reserveCloudflareBudget(estimatedNeurons: number): Promise<Record<string, unknown>> {
		const state = await this.state();
		this.normalizeDay(state);
		const estimate = Math.max(1, Number(estimatedNeurons) || 1);
		const projected = state.dailyNeurons + state.dailyReservedNeurons + estimate;
		if (state.quotaExhaustedDate === state.dailyDate || projected > WIKI_CLOUDFLARE_NEURON_TARGET) {
			await this.saveState(state);
			return {
				ok: false,
				dailyNeurons: state.dailyNeurons,
				dailyReservedNeurons: state.dailyReservedNeurons,
				targetNeurons: WIKI_CLOUDFLARE_NEURON_TARGET,
			};
		}
		state.dailyReservedNeurons += estimate;
		await this.saveState(state);
		return { ok: true, reserved: estimate, dailyNeurons: state.dailyNeurons, dailyReservedNeurons: state.dailyReservedNeurons };
	}

	async settleCloudflareBudget(reservedNeurons: number, actualNeurons: number): Promise<Record<string, unknown>> {
		const state = await this.state();
		this.normalizeDay(state);
		const reserved = Math.max(0, Number(reservedNeurons) || 0);
		const actual = Math.max(0, Number(actualNeurons) || 0);
		state.dailyReservedNeurons = Math.max(0, state.dailyReservedNeurons - reserved);
		state.dailyNeurons += actual;
		await this.saveState(state);
		return { ok: true, dailyNeurons: state.dailyNeurons, dailyReservedNeurons: state.dailyReservedNeurons, targetNeurons: WIKI_CLOUDFLARE_NEURON_TARGET };
	}

	async releaseCloudflareBudget(reservedNeurons: number): Promise<Record<string, unknown>> {
		const state = await this.state();
		this.normalizeDay(state);
		state.dailyReservedNeurons = Math.max(0, state.dailyReservedNeurons - Math.max(0, Number(reservedNeurons) || 0));
		await this.saveState(state);
		return { ok: true, dailyReservedNeurons: state.dailyReservedNeurons };
	}

	async getCloudflareBudget(): Promise<Record<string, unknown>> {
		const state = await this.state();
		this.normalizeDay(state);
		await this.saveState(state);
		return {
			dateUTC: state.dailyDate,
			dailyNeurons: Math.round(state.dailyNeurons * 100) / 100,
			dailyReservedNeurons: Math.round(state.dailyReservedNeurons * 100) / 100,
			targetNeurons: WIKI_CLOUDFLARE_NEURON_TARGET,
			quotaExhaustedDate: state.quotaExhaustedDate,
		};
	}

	async getArticle(code: string): Promise<PublishedArticle | null> {
		return (await this.ctx.storage.get<PublishedArticle>(`article:${code}`)) ?? null;
	}

	async getRecent(limit = 10): Promise<LastPublished[]> {
		const recent =
			(await this.ctx.storage.get<LastPublished[]>("wiki:recent")) ?? [];
		return recent.slice(0, Math.max(1, Math.min(30, limit)));
	}

	async getStatus(): Promise<Record<string, unknown>> {
		const state = await this.state();
		this.normalizeDay(state);
		this.normalizeCursor(state);
		await this.saveState(state);

		const languages = WIKI_LANGUAGE_ORDER.map((language, index) => ({
			slug: language.slug,
			name: language.name,
			total: language.total,
			published: state.completedByLanguage[language.slug] || 0,
			failed: state.failedByLanguage[language.slug] || 0,
			status:
				index < state.languageIndex
					? "complete"
					: index === state.languageIndex
						? "generating"
						: "pending",
		}));

		return {
			service: "MASTER LANGUAGE SYSTEM — Wiki autónoma",
			promptVersion: WIKI_PROMPT_VERSION,
			totalEntries: WIKI_TOTAL_ENTRIES,
			totalPublished: state.totalPublished,
			totalFailed: state.totalFailed,
			remaining: Math.max(0, WIKI_TOTAL_ENTRIES - state.totalPublished - state.totalFailed),
			dailyDateUTC: state.dailyDate,
			dailyClaims: state.dailyClaims,
			dailyPromptTokens: state.dailyPromptTokens,
			dailyCompletionTokens: state.dailyCompletionTokens,
			dailyNeurons: Math.round(state.dailyNeurons * 100) / 100,
			dailyNeuronTarget: WIKI_CLOUDFLARE_NEURON_TARGET,
			dailyQuotaTargetPercent: 90,
			dailyReservedNeurons: Math.round(state.dailyReservedNeurons * 100) / 100,
			quotaExhaustedDate: state.quotaExhaustedDate,
			dailyQuotaUsedPercent: Math.round((state.dailyNeurons / 10000) * 10000) / 100,
			estimatedArticleNeurons:
				Math.round(
					(state.historicalArticleCount > 0
						? state.historicalArticleNeurons / state.historicalArticleCount
						: 150) * 100,
				) / 100,
			activeClaim: state.claim,
			lastPublished: state.lastPublished,
			lastError: state.lastError,
			startedAt: state.startedAt,
			languages,
		};
	}
}
