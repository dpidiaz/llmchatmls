/**
 * Type definitions for MASTER LANGUAGE SYSTEM Revision 32.
 */

import type { WikiStore } from "./wiki-store";

export interface Env {
	/** Workers AI — Profesor IA + proveedor Cloudflare del motor editorial */
	AI: Ai;

	/** Static application assets */
	ASSETS: { fetch: (request: Request) => Promise<Response> };

	/** Legacy/persistent coordination store from Revision 31 (also guards the Cloudflare AI budget). */
	WIKI_STORE: DurableObjectNamespace<WikiStore>;

	/** Revision 32 persistent SQL store — automatically provisioned by Wrangler. */
	WIKI_DB: D1Database;

	/** Revision 32 parallel generation queue. */
	WIKI_QUEUE: Queue;

	/**
	 * Optional Cloudflare Secret containing a JSON array of external AI providers.
	 * This is intentionally optional: Revision 32 works with Workers AI alone and
	 * automatically expands when external providers are configured.
	 */
	MLS_EXTERNAL_PROVIDERS_JSON?: string;
}

export interface ChatMessage {
	role: "system" | "user" | "assistant";
	content: string;
}
