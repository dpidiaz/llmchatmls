import { DurableObject } from "cloudflare:workers";
import type { Env } from "./types";
import {
	WIKI_CLAIM_TTL_MS,
	WIKI_LANGUAGE_ORDER,
	WIKI_PROMPT_VERSION,
	WIKI_TOTAL_ENTRIES,
} from "./wiki-config";

interface ActiveClaim {
	code: string;
	language: string;
	languageName: string;
	n: number;
	seedPath: string;
	claimedAt: number;
}

interface LastPublished {
	code: string;
	language: string;
	title: string;
	generatedAt: string;
}

interface WikiState {
	version: number;
	startedAt: string;
	languageIndex: number;
	nextN: number;
	totalPublished: number;
	totalFailed: number;
	completedByLanguage: Record<string, number>;
	failedByLanguage: Record<string, number>;
	dailyDate: string;
	dailyClaims: number;
	claim: ActiveClaim | null;
	lastPublished: LastPublished | null;
	lastError: { code: string; message: string; at: string } | null;
}

interface PublishedArticle {
	code: string;
	language: string;
	languageName: string;
	n: number;
	title: string;
	level: string;
	part: string;
	chapter: string;
	articleMarkdown: string;
	model: string;
	promptVersion: string;
	generatedAt: string;
}

function utcDate(now = Date.now()): string {
	return new Date(now).toISOString().slice(0, 10);
}

function initialCounts(): Record<string, number> {
	return Object.fromEntries(WIKI_LANGUAGE_ORDER.map((language) => [language.slug, 0]));
}

function defaultState(): WikiState {
	return {
		version: 1,
		startedAt: new Date().toISOString(),
		languageIndex: 0,
		nextN: 1,
		totalPublished: 0,
		totalFailed: 0,
		completedByLanguage: initialCounts(),
		failedByLanguage: initialCounts(),
		dailyDate: utcDate(),
		dailyClaims: 0,
		claim: null,
		lastPublished: null,
		lastError: null,
	};
}

export class WikiStore extends DurableObject<Env> {
	constructor(ctx: DurableObjectState, env: Env) {
		super(ctx, env);
	}

	private async state(): Promise<WikiState> {
		const stored = await this.ctx.storage.get<WikiState>("wiki:state");
		if (stored) return stored;
		const created = defaultState();
		await this.ctx.storage.put("wiki:state", created);
		return created;
	}

	private async saveState(state: WikiState): Promise<void> {
		await this.ctx.storage.put("wiki:state", state);
	}

	private normalizeDay(state: WikiState): void {
		const today = utcDate();
		if (state.dailyDate !== today) {
			state.dailyDate = today;
			state.dailyClaims = 0;
		}
	}

	private normalizeCursor(state: WikiState): void {
		while (state.languageIndex < WIKI_LANGUAGE_ORDER.length) {
			const language = WIKI_LANGUAGE_ORDER[state.languageIndex];
			if (state.nextN <= language.total) return;
			state.languageIndex += 1;
			state.nextN = 1;
		}
	}

	async claimNext(dailyLimit: number): Promise<Record<string, unknown>> {
		const state = await this.state();
		const now = Date.now();
		this.normalizeDay(state);
		this.normalizeCursor(state);

		if (state.claim) {
			const age = now - state.claim.claimedAt;
			if (age < WIKI_CLAIM_TTL_MS) {
				await this.saveState(state);
				return {
					status: "busy",
					message: `Ya se está procesando ${state.claim.code}.`,
					claim: state.claim,
				};
			}
			state.lastError = {
				code: state.claim.code,
				message: "La reclamación anterior expiró y será reintentada.",
				at: new Date().toISOString(),
			};
			state.claim = null;
		}

		if (state.languageIndex >= WIKI_LANGUAGE_ORDER.length) {
			await this.saveState(state);
			return {
				status: "complete",
				message: "Las diez enciclopedias ya fueron recorridas.",
			};
		}

		if (state.dailyClaims >= dailyLimit) {
			await this.saveState(state);
			return {
				status: "daily-limit",
				message: `Se alcanzó el límite autónomo de ${dailyLimit} intentos para ${state.dailyDate} UTC.`,
			};
		}

		const language = WIKI_LANGUAGE_ORDER[state.languageIndex];
		const n = state.nextN;
		const padded = String(n).padStart(4, "0");
		const code = `${language.prefix}-${padded}`;
		const claim: ActiveClaim = {
			code,
			language: language.slug,
			languageName: language.name,
			n,
			seedPath: `/data/wiki-seeds/${language.slug}/${padded}.json`,
			claimedAt: now,
		};

		state.claim = claim;
		state.dailyClaims += 1;
		await this.saveState(state);
		return { status: "claimed", ...claim };
	}

	async publish(article: PublishedArticle): Promise<{ ok: true; code: string }> {
		const state = await this.state();
		const key = `article:${article.code}`;
		const existing = await this.ctx.storage.get<PublishedArticle>(key);

		if (!existing) {
			await this.ctx.storage.put(key, article);
		}

		if (state.claim?.code === article.code) {
			const language = WIKI_LANGUAGE_ORDER[state.languageIndex];
			if (language && language.slug === article.language && state.nextN === article.n) {
				state.totalPublished += existing ? 0 : 1;
				state.completedByLanguage[article.language] =
					(state.completedByLanguage[article.language] || 0) + (existing ? 0 : 1);
				state.nextN += 1;
				this.normalizeCursor(state);
			}
			state.claim = null;
		}

		state.lastPublished = {
			code: article.code,
			language: article.language,
			title: article.title,
			generatedAt: article.generatedAt,
		};
		state.lastError = null;

		const recent =
			(await this.ctx.storage.get<LastPublished[]>("wiki:recent")) ?? [];
		const updatedRecent = [state.lastPublished, ...recent.filter((item) => item.code !== article.code)].slice(0, 30);
		await this.ctx.storage.put("wiki:recent", updatedRecent);
		await this.saveState(state);
		return { ok: true, code: article.code };
	}

	async recordFailure(
		code: string,
		message: string,
	): Promise<Record<string, unknown>> {
		const state = await this.state();
		const countKey = `failure-count:${code}`;
		const count = ((await this.ctx.storage.get<number>(countKey)) ?? 0) + 1;
		await this.ctx.storage.put(countKey, count);

		state.lastError = { code, message, at: new Date().toISOString() };

		let skipped = false;
		if (state.claim?.code === code) {
			if (count >= 3) {
				const language = state.claim.language;
				state.totalFailed += 1;
				state.failedByLanguage[language] = (state.failedByLanguage[language] || 0) + 1;
				await this.ctx.storage.put(`failure:${code}`, {
					code,
					message,
					attempts: count,
					at: new Date().toISOString(),
				});
				state.nextN += 1;
				this.normalizeCursor(state);
				skipped = true;
			}
			state.claim = null;
		}

		await this.saveState(state);
		return { ok: false, code, attempts: count, skipped };
	}

	async getArticle(code: string): Promise<PublishedArticle | null> {
		return (await this.ctx.storage.get<PublishedArticle>(`article:${code}`)) ?? null;
	}

	async getRecent(limit = 10): Promise<LastPublished[]> {
		const recent =
			(await this.ctx.storage.get<LastPublished[]>("wiki:recent")) ?? [];
		return recent.slice(0, Math.max(1, Math.min(30, limit)));
	}

	async getStatus(): Promise<Record<string, unknown>> {
		const state = await this.state();
		this.normalizeDay(state);
		this.normalizeCursor(state);
		await this.saveState(state);

		const languages = WIKI_LANGUAGE_ORDER.map((language, index) => ({
			slug: language.slug,
			name: language.name,
			total: language.total,
			published: state.completedByLanguage[language.slug] || 0,
			failed: state.failedByLanguage[language.slug] || 0,
			status:
				index < state.languageIndex
					? "complete"
					: index === state.languageIndex
						? "generating"
						: "pending",
		}));

		return {
			service: "MASTER LANGUAGE SYSTEM — Wiki autónoma",
			promptVersion: WIKI_PROMPT_VERSION,
			totalEntries: WIKI_TOTAL_ENTRIES,
			totalPublished: state.totalPublished,
			totalFailed: state.totalFailed,
			remaining: Math.max(0, WIKI_TOTAL_ENTRIES - state.totalPublished - state.totalFailed),
			dailyDateUTC: state.dailyDate,
			dailyClaims: state.dailyClaims,
			activeClaim: state.claim,
			lastPublished: state.lastPublished,
			lastError: state.lastError,
			startedAt: state.startedAt,
			languages,
		};
	}
}
