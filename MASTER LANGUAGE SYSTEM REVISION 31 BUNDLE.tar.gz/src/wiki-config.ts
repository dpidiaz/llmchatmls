export const WIKI_PROMPT_VERSION = "31.0";
export const WIKI_DAILY_LIMIT = 40;
export const WIKI_CLAIM_TTL_MS = 2 * 60 * 60 * 1000;

export const WIKI_LANGUAGE_ORDER = [
	{ slug: "espanol-guatemala", name: "Español de Guatemala", total: 930, prefix: "MLS-V10" },
	{ slug: "ingles", name: "Inglés", total: 766, prefix: "MLS-V01" },
	{ slug: "portugues", name: "Portugués brasileño", total: 1199, prefix: "MLS-V02" },
	{ slug: "italiano", name: "Italiano", total: 810, prefix: "MLS-V03" },
	{ slug: "frances", name: "Francés", total: 1159, prefix: "MLS-V04" },
	{ slug: "aleman", name: "Alemán", total: 1101, prefix: "MLS-V05" },
	{ slug: "japones", name: "Japonés", total: 1027, prefix: "MLS-V06" },
	{ slug: "chino-taiwan", name: "Chino mandarín de Taiwán", total: 1016, prefix: "MLS-V07" },
	{ slug: "coreano", name: "Coreano", total: 1094, prefix: "MLS-V08" },
	{ slug: "ruso", name: "Ruso", total: 1031, prefix: "MLS-V09" },
] as const;

export const WIKI_TOTAL_ENTRIES = WIKI_LANGUAGE_ORDER.reduce((sum, item) => sum + item.total, 0);
