/**
 * Type definitions for MASTER LANGUAGE SYSTEM.
 */

import type { WikiStore } from "./wiki-store";

export interface Env {
	/** Workers AI */
	AI: Ai;

	/** Static application assets */
	ASSETS: { fetch: (request: Request) => Promise<Response> };

	/** Persistent autonomous wiki storage */
	WIKI_STORE: DurableObjectNamespace<WikiStore>;

	/** Scheduled autonomous generator */
	WIKI_GENERATOR: Workflow;
}

export interface ChatMessage {
	role: "system" | "user" | "assistant";
	content: string;
}
